#!/bin/bash
#
#   [ shocker - docker - sabnzbdplus - config ]
#


    # application
    application_name='sabnzbdplus.ubuntu-trusty.ppa.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_media='/media'

    # docker
    docker_name='shocker_sabnzbdplus_ubuntu-trusty_ppa'
    docker_tag='shocker/sabnzbdplus_ubuntu-trusty_ppa'

    # sabnzbd
    docker_config='/root/.sabnzbd'
    docker_log='/var/log/sabnzbd'
    docker_media='/media'


#
#   [ end ]
#
