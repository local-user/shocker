#!/bin/bash
#
#   [ shocker - docker - sabnzbdplus - config ]
#


    # application
    application_name='sabnzbdplus.ubuntu-trusty.ppa.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_download='/media/download/sabnzbd'
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_video_movie='/media/video/movie'

    # docker
    docker_name='shocker_sabnzbdplus_ubuntu-trusty_ppa'
    docker_tag='shocker/sabnzbdplus_ubuntu-trusty_ppa'

    # sabnzbd
    docker_config='/root/.sabnzbd'
    docker_download='/media/download/sabnzbd'
    docker_log='/var/log/sabnzbd'


#
#   [ end ]
#
