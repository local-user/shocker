#!/bin/bash
#
#   [ shocker - docker - couchpotato - config ]
#


    # application
    application_name='couchpotato.ubuntu-trusty.git.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_media='/media'

    # docker
    docker_name='shocker_couchpotato_ubuntu-trusty_git'
    docker_tag='shocker/couchpotato_ubuntu-trusty_git'

    # couchpotato
    docker_config='/root/.couchpotato'
    docker_log='/var/log/couchpotato'
    docker_media='/media'


#
#   [ end ]
#
