#!/bin/bash
#
#   [ shocker - docker - transmission - config ]
#


    # application
    application_name='transmission.ubuntu-vivid.ppa.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_media='/media'

    # docker
    docker_name='shocker_transmission_ubuntu-vivid_ppa'
    docker_tag='shocker/transmission_ubuntu-vivid_ppa'

    # transmission
    docker_config='/root/.config/transmission-daemon'
    docker_log='/var/log/transmission'
    docker_media='/media'


#
#   [ end ]
#
