#!/bin/bash
#
#   [ shocker - docker - miv - config ]
#


    # application
    application_name='miv.ubuntu-trusty.git.no-persist.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"

    # docker
    docker_name='shocker_miv_ubuntu-trusty_git'
    docker_tag='shocker/miv_ubuntu-trusty_git'

    # miv
    docker_config='/root/.config/miv'
    docker_log='/var/log/apache2'


#
#   [ end ]
#
