#!/bin/bash
#
#   [ shocker - docker - headphones - config ]
#


    # application
    application_name='headphones.ubuntu-trusty.git.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_media='/media'

    # docker
    docker_name='shocker_headphones_ubuntu-trusty_git'
    docker_tag='shocker/headphones_ubuntu-trusty_git'

    # headphones
    docker_config='/root/.headphones'
    docker_log='/var/log/headphones'
    docker_media='/media'


#
#   [ end ]
#
