#!/bin/bash
#
#   [ shocker - docker - sonarr - config ]
#


    # application
    application_name='sonarr.ubuntu-trusty.ppa.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_media='/media'

    # docker
    docker_name='shocker_sonarr_ubuntu-trusty_ppa'
    docker_tag='shocker/sonarr_ubuntu-trusty_ppa'

    # sonarr
    docker_config='/root/.config/NzbDrone'
    docker_log='/var/log/sonarr'
    docker_media='/media'


#
#   [ end ]
#
