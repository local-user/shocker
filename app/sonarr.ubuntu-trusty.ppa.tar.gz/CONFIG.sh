#!/bin/bash
#
#   [ shocker - docker - sonarr - config ]
#


    # application
    application_name='sonarr.ubuntu-trusty.ppa.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_download='/media/download'
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_video_tv='/media/video/tv'

    # docker
    docker_name='shocker_sonarr_ubuntu-trusty_ppa'
    docker_tag='shocker/sonarr_ubuntu-trusty_ppa'

    # sonarr
    docker_config='/root/.config/NzbDrone'
    docker_download='/media/download'
    docker_log='/var/log/sonarr'
    docker_video_tv='/media/video/tv'


#
#   [ end ]
#
