# shocker - transmission
