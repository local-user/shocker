#!/bin/bash
#
#   [ shocker - docker - couchpotato - config ]
#


    # application
    application_name='couchpotato.tar.gz'

    # host
    host_config="$HOME/.config/shocker/run/$application_name/config"
    host_download='/media/download/couchpotato'
    host_log="$HOME/.config/shocker/run/$application_name/log"
    host_video_movie='/media/video/movie'

    # docker
    docker_name='shocker_couchpotato'
    docker_tag='shocker/couchpotato'

    # couchpotato
    docker_config='/root/.couchpotato'
    docker_download='/media/download'
    docker_log='/var/log/couchpotato'
    docker_video_movie='/media/video/movie'


#
#   [ end ]
#
