#!/bin/bash
#
#   [ shocker - docker - nzbget - config ]
#


    # application
    application_name='nzbget.tar.gz'

    # host
    host="$HOME/.config/shocker"
    host_config="$host/run/$application_name/config/nzbget"
    host_config_nzbtomedia="$host/run/$application_name/config/nzbtomedia"
    host_download='/media/download/nzbget'
    host_log="$host/run/$application_name/log"

    # docker
    docker_name='shocker_nzbget'
    docker_tag='shocker/nzbget'

    # nzbget
    docker_config='/etc/nzbget'
    docker_config_nzbtomedia='/etc/nzbToMedia'
    docker_download='/media/download/nzbget'
    docker_log='/var/log/nzbget'


#
#   [ end ]
#
